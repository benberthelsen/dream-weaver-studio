-- Update supplier URLs to working pages
UPDATE suppliers SET website_url = 'https://www.lavistone.com.au/our-range/' WHERE slug = 'lavistone';
UPDATE suppliers SET website_url = 'https://www.lithostonequartzsurfaces.com.au/lithostone/' WHERE slug = 'lithostone';
UPDATE suppliers SET website_url = 'https://www.smartstone.com.au/stones/' WHERE slug = 'smartstone';
UPDATE suppliers SET website_url = 'https://www.hafele.com.au/en/c/furniture-fittings/10050000/' WHERE slug = 'hafele';