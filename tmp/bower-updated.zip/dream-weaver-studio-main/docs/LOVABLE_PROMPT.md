# Lovable Build Prompt — Bower Building (DIY Cut‑to‑Size Cabinets)

Paste this into Lovable to build/extend the public DIY site while keeping the existing Pro Tools (Collections/Board/Admin).

---

## Goal
Create a public, conversion-focused DIY cabinetry website (like a modern SaaS landing page) for **Bower Building / Bower Cabinets** that matches a clean **navy + orange** theme.

Two audiences:
1) **DIY customers**: design online, get quote, order cut-to-size flat-pack cabinets.
2) **Trade/Pro**: access existing tools (Collections, Board Builder, Admin).

---

## Routes (public)
- `/` Home
- `/how-it-works`
- `/pricing`
- `/gallery`
- `/room-planner`
- `/faq`
- `/contact`

## Routes (pro)
- `/collections`
- `/board`
- `/admin`

---

## Navigation
Header has two modes:
- **Public nav:** Home | How It Works | Pricing | Gallery | Room Planner | FAQ | Contact
- Right side: **Pro Tools** button (links to `/board`)

Primary CTA on public pages: **Start Designing** (links to `/room-planner`)
Secondary CTA: **See Example Pricing** (links to `/pricing`)

---

## Design system (tokens)
Use Tailwind + CSS variables.
- Primary (navy): `#1E2A3A`
- Accent (orange): `#E06A2A`
- Background: `#F6F7F9`
- Card: `#FFFFFF`
- Text: `#1A1A1A`
- Border: `#E6E8EC`

Fonts:
- Headings: Montserrat
- Body: Inter

Style rules:
- Hero: full-width image with dark navy gradient overlay; big H1; two CTAs.
- Sections: generous whitespace; clean card grids; consistent button styling.
- Cards: rounded corners, soft shadow on hover.

---

## Page content structure
### Home
1) Hero
2) Trust strip (CNC cut + drilled, edge-banded finish, soft-close options, delivery)
3) 3-step process
4) Benefits grid
5) Big-box comparison teaser
6) Supplier logos
7) Gallery preview
8) Testimonials
9) CTA banner + footer

### How It Works
Four steps with icons + short copy; CTA to Room Planner.

### Pricing
Example pricing table + comparison table; 3 example project cards; CTA to Room Planner.

### Gallery
Filters: Kitchen | Laundry | Bathroom | Wardrobe.

### Room Planner
Headline + strong CTA to open planner; optionally embed iframe if URL supports.

### FAQ
Accordion grouped: Ordering, Materials, Delivery & Assembly, Pricing.

### Contact
Form fields: Name, Email, Phone, Project Type, Message.
Store submissions in `contact_submissions` (insert-only anon).

---

## Reference images (already in repo)
Use these from `public/assets/` for layout inspiration / placeholders:
- `bower_homepage_long.png`
- `bower_mockups_board.png`
- `bower_mockups_8.png`
- `bower_diy_style.png`
